-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2019 at 09:05 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `l6app`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `title`, `content`, `thumbnail`, `created_at`, `updated_at`) VALUES
(1, 0, 'News', 'This is news category', 'abc.jpg', '2019-12-27 18:30:00', '2019-12-27 18:30:00'),
(2, 0, 'Movies', 'This is Movies category', 'abc.jpg', '2019-12-27 18:30:00', '2019-12-27 18:30:00'),
(3, 0, 'Sports', 'This is Sportscategory', 'abc.jpg', '2019-12-27 18:30:00', '2019-12-27 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_045129_create_todos_table', 1),
(5, '2019_12_17_095846_create_posts_table', 1),
(6, '2019_12_17_112456_create_users_profiles_table', 1),
(7, '2019_12_19_064629_create_roles_table', 1),
(8, '2019_12_19_064921_create_users_roles_table', 1),
(9, '2019_12_27_103753_create_categories_table', 1),
(10, '2019_12_27_103812_create_pages_table', 1),
(11, '2019_12_27_104424_create_countries_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('sameer.smartitventures@gmail.com', '$2y$10$3apekZGsrIJbAWV1ImMqhOT9QQTgRgyRU3tflTFAeS2afwsRrLACq', '2019-12-27 07:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `content`, `thumbnail`, `created_at`, `updated_at`) VALUES
(1, 2, 3, 'Sapiente veniam velit.', 'Eos voluptas inventore sit exercitationem non doloribus illum nulla quaerat laudantium similique totam tempora ratione cumque repellendus voluptatem et illo quis rem.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(2, 1, 1, 'Officiis in magni.', 'Delectus quia eligendi odio nihil eligendi architecto voluptatibus voluptas odio expedita voluptatem ea nulla molestias exercitationem maiores omnis saepe temporibus officiis.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(3, 3, 2, 'Similique nisi natus.', 'Libero aliquid accusantium quidem ea fuga est voluptatum ea vel quod molestiae numquam maxime quos odio recusandae esse perferendis suscipit molestiae qui enim sapiente ut quisquam rerum consequatur quae rem occaecati fuga fuga rem.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(4, 3, 2, 'Dolore placeat esse maxime.', 'Porro nulla et voluptatem ut et accusantium cum qui facilis harum sint hic corrupti quis voluptatibus voluptas aut velit eveniet doloremque possimus velit ut quia et in tempora vel qui amet.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(5, 1, 1, 'Hic debitis sed.', 'Dolorem omnis sequi ut atque sunt totam quos omnis soluta culpa delectus voluptatum et exercitationem ad aliquid consequatur quas accusamus eum voluptatum tenetur natus quam accusamus quisquam libero rerum eos culpa alias deserunt perspiciatis ut sunt dolorem soluta assumenda.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(6, 3, 4, 'Numquam suscipit explicabo voluptatem.', 'Eveniet quaerat labore doloribus eveniet ab accusamus nihil nemo sed laboriosam deserunt in inventore omnis vel nisi ut et qui officiis et sed magni cum qui ducimus sequi est odit nam non dolore nostrum.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(7, 1, 3, 'Ea animi velit.', 'Ea corrupti omnis cupiditate sunt consectetur qui voluptas ut nulla perspiciatis consequuntur fugiat et asperiores ut commodi sed voluptatem optio vitae enim ratione rerum enim accusantium quia aut voluptatum atque aut.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(8, 3, 2, 'Est et excepturi possimus amet.', 'A et est commodi ut natus ut doloremque dolores dignissimos maxime ut assumenda qui velit nemo quia beatae quasi rerum vel.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(9, 1, 3, 'Tenetur inventore laudantium non.', 'Dolorum ducimus ut veniam repellat laboriosam quis explicabo mollitia modi accusantium consequatur facere explicabo sit aliquid corporis modi necessitatibus amet est enim est neque sed ut sint atque repudiandae dolor est voluptate deserunt officia eos incidunt tenetur maiores sed sed animi.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(10, 2, 2, 'Ratione eligendi blanditiis qui.', 'Est quos velit sint possimus rem cum omnis quo accusamus porro sequi eos deserunt temporibus non enim nihil possimus sit nulla reiciendis possimus tempora architecto aut libero quia.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(11, 2, 4, 'Accusamus saepe illo officiis laboriosam.', 'Architecto corrupti aut non omnis cum voluptatem ut consequatur et deserunt culpa voluptatibus quae et assumenda quam velit molestiae recusandae cumque unde nihil exercitationem praesentium possimus repellendus aut.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(12, 3, 2, 'Sit officiis libero qui.', 'Aliquid reprehenderit eius ut aut nostrum quasi cum laudantium perspiciatis impedit error eos praesentium dolores nihil et maiores dolores quo vitae ab maxime quos vitae fugiat omnis hic facere odit consectetur dolor optio sit neque corporis aliquam fuga quia aut cumque sed.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(13, 3, 1, 'Corrupti illo laboriosam aut.', 'Suscipit distinctio corporis et aliquam voluptas nobis rem doloremque excepturi quos in aliquid eligendi odio ex dolorem quod quis amet ducimus velit ipsam est autem laudantium velit quia quos vel reiciendis sint et tenetur sit explicabo earum at doloremque explicabo.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(14, 3, 1, 'Ullam in facere iure.', 'Ea hic libero minus similique enim perspiciatis ut tempore necessitatibus beatae minus sunt quo aliquid nisi cupiditate non porro fuga ut qui recusandae qui rerum accusantium ducimus et aut impedit aperiam perferendis tenetur reprehenderit nihil distinctio.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(15, 1, 3, 'Quia eligendi recusandae exercitationem.', 'Nihil deserunt voluptatem amet veritatis et in ad sequi dolores eaque beatae consequuntur dolorem aliquam quia consequatur et quaerat non quo vel aperiam iste quia et vel aut earum ab.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(16, 3, 4, 'Ullam occaecati aliquam.', 'Qui perspiciatis perspiciatis itaque quidem et sapiente porro ducimus consequatur dolor deserunt sunt qui velit eius aut et nostrum aut totam et accusantium cumque fuga a consequatur aspernatur perferendis sit et adipisci.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(17, 2, 2, 'Optio ipsum sapiente incidunt.', 'Eius aspernatur sit est ut beatae dolores eveniet atque ducimus omnis alias asperiores minus soluta sed incidunt dolore in ea delectus nisi nam molestiae voluptatibus dicta velit nemo.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(18, 1, 3, 'Ut rerum debitis.', 'Et dolor ipsa mollitia omnis rem fugit ut inventore quos et optio et magni qui assumenda assumenda amet officia nulla asperiores quisquam eaque doloribus voluptas aperiam ut voluptate nesciunt quasi et alias dolorum delectus quibusdam voluptatem nulla.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(19, 2, 3, 'Magnam nam ut.', 'Nesciunt sit repellat totam laudantium qui sunt omnis quos ab quia et vel sunt deleniti facere non nobis facere.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(20, 3, 3, 'Architecto mollitia reprehenderit commodi doloribus.', 'Adipisci accusantium eum nesciunt sed saepe rerum ea non ut id dignissimos dolor ratione itaque ipsam consequatur perspiciatis voluptas neque numquam vero molestias molestiae explicabo corrupti minima repellendus inventore perspiciatis accusantium tempore nihil ullam minima error asperiores qui cumque officiis saepe.', 'abc.jpg', '2019-12-28 02:54:40', '2019-12-28 02:54:40'),
(21, 2, 1, 'Accusamus ut facere.', 'Earum dolores accusantium tenetur ex voluptatem hic odit rerum aliquam sed odit et ut rerum soluta modi voluptates quaerat repellat nostrum fugiat perspiciatis cupiditate omnis earum accusantium et odio nulla et pariatur consectetur ut tempore fugiat consequuntur expedita cumque perferendis et vel quia.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(22, 1, 2, 'Qui consequatur qui.', 'Molestiae beatae incidunt quisquam dolor quas rerum recusandae in ut non dolore placeat reprehenderit quia doloremque commodi necessitatibus eveniet est accusamus et quidem vero doloribus consequatur a quis sint et vero qui deleniti.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(23, 3, 1, 'Sed itaque.', 'Et et expedita totam et inventore reprehenderit autem expedita aperiam qui quis dolores reiciendis aperiam occaecati autem impedit unde magni amet et necessitatibus est ut ducimus alias est.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(24, 2, 4, 'Aut dicta itaque.', 'At ducimus quia dicta similique eum fuga beatae corporis et qui consequatur libero sequi non incidunt et nulla adipisci ut perspiciatis non provident et perspiciatis animi consequatur in et numquam eius rerum saepe consequatur neque eligendi sunt ut animi aspernatur.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(25, 2, 4, 'Tempore sit aliquid aut.', 'Magni voluptas ut incidunt molestiae tempore doloribus odio voluptas molestiae cupiditate cumque suscipit tempore et perspiciatis molestias dolor autem et rerum fugit iusto et voluptatum voluptatem earum dolorem tenetur eum est voluptatum.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(26, 1, 3, 'Ea distinctio minus beatae.', 'Temporibus voluptatem commodi quis laboriosam aperiam ex eius totam alias quae aliquam molestias vel quos rerum explicabo sed temporibus est perspiciatis delectus corrupti ut qui et suscipit.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(27, 2, 2, 'Sint est quo consequuntur.', 'Consequatur modi qui eius inventore rerum sed voluptas atque itaque aut vero occaecati iure autem voluptate non labore delectus.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(28, 2, 1, 'Eligendi dolores voluptatem aspernatur.', 'Sint repellendus blanditiis qui numquam dolores officia libero qui et tempore rerum fugit illum dolores voluptas fuga voluptatem ut itaque omnis delectus enim ad non et voluptatem non architecto.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(29, 3, 3, 'Nobis accusamus.', 'Aut asperiores vel fugiat dolor possimus delectus sed maxime vel cupiditate quo molestias expedita illum quod cum tempore neque impedit quia earum et nemo sed aut consectetur occaecati sed iste consequatur dolor sed debitis quod sed itaque eaque aliquam possimus.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41'),
(30, 2, 4, 'Rerum architecto minus.', 'Molestiae aut consequatur quae itaque est repellat aut est omnis veniam et corrupti id incidunt et et ut architecto quo voluptates similique aspernatur eveniet id officiis cupiditate eius.', 'abc.jpg', '2019-12-28 02:54:41', '2019-12-28 02:54:41');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '2019-12-26 18:30:00', '2019-12-26 18:30:00'),
(2, 'Vendor', '2019-12-26 18:30:00', '2019-12-26 18:30:00'),
(3, 'customer', '2019-12-26 18:30:00', '2019-12-26 18:30:00'),
(4, 'Author', '2019-12-27 18:30:00', '2019-12-27 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2019-12-26 18:30:00', '2019-12-26 18:30:00'),
(2, 2, 3, '2019-12-26 18:30:00', '2019-12-26 18:30:00'),
(3, 3, 2, '2019-12-26 18:30:00', '2019-12-26 18:30:00'),
(4, 4, 4, '2019-12-27 18:30:00', '2019-12-27 18:30:00'),
(5, 4, 2, '2019-12-27 18:30:00', '2019-12-27 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE `todos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'sameer48', 'sameer', 'sameer.smartitventures@gmail.com', NULL, '$2y$10$.HpaX8vWCmoMQ8xjpmDlNezL.OtbymUvWSdSZmvOi77BPEfcpLwWq', 'zVguaaLcALoZh0EabrhtIbuGyiwox5bqh2KbNvnK7hlpxrAR36Li281tF5YX', '2019-12-27 05:50:22', '2019-12-27 05:50:22'),
(2, 'harpreet18', 'harpreet', 'harpreet.smartitventures@gmail.com', NULL, '$2y$10$ujhwBDJ8p9bs0dvmKg9gF.B/zdHt28FTpPTBmWV9a5iTr95KA8F1m', NULL, '2019-12-28 00:30:30', '2019-12-28 00:30:30'),
(3, 'dilawar30', 'dilawar', 'dilwar.smartitventures@gmail.com', NULL, '$2y$10$S43Y9Lc8u6Hln0N9V3.cIeACHQoQQTd2zZBOECm2FZNNHow88P3j6', NULL, '2019-12-28 00:54:24', '2019-12-28 00:54:24'),
(4, 'Ajay36', 'Ajay', 'ajay.smartitventures@gmail.com', NULL, '$2y$10$39A22XODsMoJvzm0.qAr7OgJiCj82hazsDQvVc50vTK/265B.ScLq', NULL, '2019-12-28 01:42:23', '2019-12-28 01:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `users_profiles`
--

CREATE TABLE `users_profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_id` bigint(20) NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `todos`
--
ALTER TABLE `todos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_profiles`
--
ALTER TABLE `users_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_profiles_user_id_unique` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `todos`
--
ALTER TABLE `todos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_profiles`
--
ALTER TABLE `users_profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
